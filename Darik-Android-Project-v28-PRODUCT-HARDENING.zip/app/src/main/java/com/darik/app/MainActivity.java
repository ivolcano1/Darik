package com.darik.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import android.app.Dialog;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.FrameLayout;
import android.graphics.Typeface;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {
    private EditText search;
    private TextView history;
    private ScrollView homeScroll;
    private View searchWrap;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        View root = findViewById(R.id.mainRoot);
        if (root != null) {
            final int left = root.getPaddingLeft(), top = root.getPaddingTop();
            final int right = root.getPaddingRight(), bottom = root.getPaddingBottom();
            ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
                Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                view.setPadding(left + bars.left, top + bars.top, right + bars.right, bottom + bars.bottom);
                return insets;
            });
            ViewCompat.requestApplyInsets(root);
        }

        MaterialButton start = findViewById(R.id.btnStart);
        TextView unknown = findViewById(R.id.btnUnknown);
        history = findViewById(R.id.historyText);
        search = findViewById(R.id.searchInput);
        homeScroll = findViewById(R.id.homeScroll);
        searchWrap = findViewById(R.id.searchWrap);

        updateCount();
        start.setOnClickListener(v -> submitSearch());
        search.setOnEditorActionListener((v, actionId, event) -> {
            submitSearch();
            return true;
        });
        findViewById(R.id.btnSearchSubmit).setOnClickListener(v -> submitSearch());
        unknown.setOnClickListener(v -> open(""));

        findViewById(R.id.btnTopSearch).setOnClickListener(v -> focusSearch());
        findViewById(R.id.btnMenu).setOnClickListener(v -> showMainMenu());
        findViewById(R.id.btnHistory).setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));
        findViewById(R.id.btnDevices).setOnClickListener(v -> startActivity(new Intent(this, DevicesActivity.class)));
        findViewById(R.id.btnGuide).setOnClickListener(v -> startActivity(new Intent(this, GuideActivity.class)));

        bindCategory(R.id.catCooling, "مكيف");
        bindCategory(R.id.catFridge, "ثلاجة");
        bindCategory(R.id.catLaundry, "غسالة");
        bindCategory(R.id.catKitchen, "فرن كهربائي");
        bindCategory(R.id.catPlumbing, "حنفية");
        bindCategory(R.id.catElectric, "مفتاح كهرباء");
        bindCategory(R.id.catElectronics, "تلفزيون");
        bindCategory(R.id.catNetwork, "راوتر الإنترنت");
        bindCategory(R.id.catWater, "ضغط المياه ضعيف في المنزل");
        bindCategory(R.id.catCleaning, "مكنسة كهربائية");
        bindCategory(R.id.issueNoPower, "الجهاز لا يعمل");
        bindCategory(R.id.issueLeak, "تسريب مياه");
        bindCategory(R.id.issueNoise, "مروحة سقف تصدر صوتًا");
        bindCategory(R.id.issueCooling, "مكيف لا يبرد");
        bindCategory(R.id.issueDrain, "غسالة لا تصرف الماء");
        bindCategory(R.id.issueHeat, "سخان مياه");
        bindCategory(R.id.issuePowerTrip, "القاطع يفصل الكهرباء");
        bindCategory(R.id.issueVibration, "الغسالة تهتز بشدة");
        bindCategory(R.id.issueRouter, "راوتر الإنترنت");
        bindCategory(R.id.issueDoor, "باب لا يغلق جيدًا");
        bindCategory(R.id.issueLamp, "لمبة تومض");
        bindCategory(R.id.issuePressure, "ضغط المياه ضعيف في المنزل");
    }


    private void showMainMenu() {
        final Dialog dialog = new Dialog(this);
        FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(Color.TRANSPARENT);

        // Compact floating drawer: never covers the entire screen and leaves the
        // underlying home screen visible on the left and at the top/bottom.
        ScrollView drawerScroll = new ScrollView(this);
        drawerScroll.setFillViewport(true);
        drawerScroll.setClipToPadding(false);
        drawerScroll.setVerticalScrollBarEnabled(false);
        drawerScroll.setBackgroundResource(R.drawable.bg_drawer_panel);
        drawerScroll.setElevation(dp(14));

        LinearLayout drawer = new LinearLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        drawer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        drawer.setPadding(dp(14), dp(12), dp(14), dp(10));
        drawerScroll.addView(drawer, new ScrollView.LayoutParams(-1, -2));

        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        // Keep a visible strip of the home screen on every supported phone width.
        int safeWidth = Math.max(dp(1), screenWidth - dp(32));
        int drawerWidth = Math.min(Math.min(dp(300), (int) (screenWidth * 0.76f)), safeWidth);
        int safeHeight = Math.max(dp(1), screenHeight - dp(48));
        int drawerHeight = Math.min(Math.min(dp(600), (int) (screenHeight * 0.80f)), safeHeight);
        FrameLayout.LayoutParams drawerParams = new FrameLayout.LayoutParams(
                drawerWidth, drawerHeight, Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        drawerParams.setMargins(0, dp(12), dp(10), dp(12));
        overlay.addView(drawerScroll, drawerParams);
        drawerScroll.setOnClickListener(v -> { /* consume taps inside panel */ });

        LinearLayout headingRow = new LinearLayout(this);
        headingRow.setOrientation(LinearLayout.HORIZONTAL);
        headingRow.setGravity(Gravity.CENTER_VERTICAL);
        headingRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ImageView brand = new ImageView(this);
        brand.setImageResource(R.drawable.ic_darik_logo);
        brand.setContentDescription("شعار دارك");
        headingRow.addView(brand, new LinearLayout.LayoutParams(dp(38), dp(38)));
        LinearLayout headingText = new LinearLayout(this);
        headingText.setOrientation(LinearLayout.VERTICAL);
        headingText.setPadding(dp(8), 0, 0, 0);
        TextView heading = new TextView(this);
        heading.setText("دارك");
        heading.setTextSize(19);
        heading.setTypeface(null, Typeface.BOLD);
        heading.setTextColor(Color.rgb(16, 43, 80));
        TextView subheading = new TextView(this);
        subheading.setText("صيانة بيتك خطوة بخطوة");
        subheading.setTextSize(10);
        subheading.setTextColor(Color.rgb(95, 110, 130));
        headingText.addView(heading);
        headingText.addView(subheading);
        headingRow.addView(headingText, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = new TextView(this);
        close.setText("×");
        close.setTextSize(26);
        close.setTextColor(Color.rgb(95, 110, 130));
        close.setGravity(Gravity.CENTER);
        close.setContentDescription("إغلاق القائمة");
        headingRow.addView(close, new LinearLayout.LayoutParams(dp(34), dp(38)));
        drawer.addView(headingRow, new LinearLayout.LayoutParams(-1, -2));
        close.setOnClickListener(v -> dismissDrawer(dialog, drawerScroll, null));

        addDivider(drawer, 9, 8);
        addMenuRow(drawer, "⌂", "الرئيسية", () -> {
            homeScroll.smoothScrollTo(0, 0);
            search.clearFocus();
        }, dialog, drawerScroll);
        addMenuRow(drawer, "⌕", "ابدأ التشخيص", () -> focusSearch(), dialog, drawerScroll);
        addMenuRow(drawer, "▤", "دليل الأعطال", () -> startActivity(new Intent(this, GuideActivity.class)), dialog, drawerScroll);
        addMenuRow(drawer, "▦", "أجهزتي", () -> startActivity(new Intent(this, DevicesActivity.class)), dialog, drawerScroll);
        addMenuRow(drawer, "◷", "إصلاحاتي", () -> startActivity(new Intent(this, HistoryActivity.class)), dialog, drawerScroll);
        addMenuRow(drawer, "⚙", "الإعدادات والخصوصية", () -> startActivity(new Intent(this, SettingsActivity.class)), dialog, drawerScroll);
        addMenuRow(drawer, "◇", "السلامة أولًا", () -> showSafetyDialog(), dialog, drawerScroll);

        addDivider(drawer, 9, 5);
        TextView note = new TextView(this);
        note.setText("بحث محلي • يعمل دون اتصال\nالإصدار 28.0.0");
        note.setTextSize(11);
        note.setLineSpacing(dp(2), 1f);
        note.setGravity(Gravity.CENTER);
        note.setTextColor(Color.rgb(95, 110, 130));
        note.setPadding(dp(6), dp(4), dp(6), dp(2));
        drawer.addView(note, new LinearLayout.LayoutParams(-1, -2));

        overlay.setOnClickListener(v -> dismissDrawer(dialog, drawerScroll, null));
        dialog.setContentView(overlay);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams attrs = window.getAttributes();
            attrs.width = WindowManager.LayoutParams.MATCH_PARENT;
            attrs.height = WindowManager.LayoutParams.MATCH_PARENT;
            attrs.gravity = Gravity.TOP | Gravity.RIGHT;
            attrs.dimAmount = 0.30f;
            window.setAttributes(attrs);
        }
        dialog.show();
        if (window != null) window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        drawerScroll.post(() -> {
            drawerScroll.setTranslationX(drawerScroll.getWidth() + dp(12));
            drawerScroll.animate().translationX(0f).setDuration(190).start();
        });
    }

    private void addDivider(LinearLayout parent, int top, int bottom) {
        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(225, 232, 242));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(1));
        params.setMargins(0, dp(top), 0, dp(bottom));
        parent.addView(divider, params);
    }

    private void dismissDrawer(Dialog dialog, View drawer, Runnable afterClose) {
        if (drawer == null || drawer.getWidth() == 0) {
            dialog.dismiss();
            if (afterClose != null) afterClose.run();
            return;
        }
        drawer.animate().translationX(drawer.getWidth()).setDuration(160).withEndAction(() -> {
            dialog.dismiss();
            if (afterClose != null) afterClose.run();
        }).start();
    }

    private void showSafetyDialog() {
        new AlertDialog.Builder(this)
            .setTitle("السلامة أولًا")
            .setMessage("أوقف الجهاز عند وجود شرر أو رائحة احتراق أو تسريب غاز. لا تفتح الأجهزة أو التوصيلات الخطرة بنفسك. افصل الطاقة فقط إذا كان ذلك آمنًا، وابتعد عن الماء القريب من الكهرباء. عند الاشتباه بتسريب غاز، لا تشغّل مفاتيح أو لهبًا، وغادر المكان واتصل بجهة الطوارئ أو الغاز من مكان آمن.")
            .setPositiveButton("حسنًا", null).show();
    }

    private void addMenuRow(LinearLayout drawer, String symbol, String label, Runnable action, Dialog dialog, View drawerPanel) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setPadding(dp(10), 0, dp(10), 0);
        row.setBackgroundResource(R.drawable.bg_card);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, dp(43));
        rowParams.setMargins(0, dp(2), 0, dp(2));
        drawer.addView(row, rowParams);
        TextView icon = new TextView(this);
        icon.setText(symbol);
        icon.setTextSize(19);
        icon.setTextColor(Color.rgb(30, 100, 190));
        icon.setGravity(Gravity.CENTER);
        row.addView(icon, new LinearLayout.LayoutParams(dp(38), -1));
        TextView title = new TextView(this);
        title.setText(label);
        title.setTextSize(14);
        title.setTextColor(Color.rgb(25, 42, 66));
        title.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        row.addView(title, new LinearLayout.LayoutParams(0, -1, 1));
        row.setClickable(true);
        row.setFocusable(true);
        row.setOnClickListener(v -> dismissDrawer(dialog, drawerPanel, action));
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void focusSearch() {
        homeScroll.smoothScrollTo(0, Math.max(0, searchWrap.getTop()));
        search.requestFocus();
        search.post(() -> {
            InputMethodManager keyboard = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (keyboard != null) keyboard.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT);
        });
    }

    private void bindCategory(int id, String query) {
        View view = findViewById(id);
        if (view != null) view.setOnClickListener(v -> open(query));
    }

    private void open(String mode) {
        Intent intent = new Intent(this, DiagnosisActivity.class);
        intent.putExtra("mode", mode == null ? "" : mode);
        startActivity(intent);
    }

    private void submitSearch() {
        String query = search.getText().toString().trim();
        if (query.isEmpty()) {
            Toast.makeText(this, "اكتب اسم الجهاز أو وصف العطل أولًا", Toast.LENGTH_SHORT).show();
            focusSearch();
            return;
        }
        open(query);
    }

    private void updateCount() {
        if (history != null) history.setText(new RepairStore(this).count() + " عملية محفوظة");
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateCount();
    }
}
