package com.darik.app;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import java.util.List;

/** Responsive RTL screen for a user's locally saved devices. */
public class DevicesActivity extends AppCompatActivity {
    private LinearLayout list;
    private EditText name, model;
    private TextView count;
    private RepairStore store;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        store = new RepairStore(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(16), dp(12), dp(16), dp(8));
        root.setBackgroundColor(Color.rgb(242, 246, 252));

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = text("›", 34, true, Color.rgb(23, 105, 224));
        back.setGravity(Gravity.CENTER);
        back.setBackgroundResource(R.drawable.bg_icon_circle);
        toolbar.addView(back, new LinearLayout.LayoutParams(dp(46), dp(46)));
        back.setOnClickListener(v -> finish());
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(12), 0, 0, 0);
        titles.addView(text("أجهزتي", 22, true, Color.rgb(16, 43, 80)));
        titles.addView(text("أجهزة تحفظها للرجوع إليها لاحقًا", 12, false, Color.rgb(99, 117, 141)));
        toolbar.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(toolbar);

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        form.setPadding(dp(14), dp(14), dp(14), dp(14));
        form.setBackgroundResource(R.drawable.bg_card);
        form.setElevation(dp(1));
        LinearLayout.LayoutParams formParams = new LinearLayout.LayoutParams(-1, -2);
        formParams.setMargins(0, dp(14), 0, dp(12));
        root.addView(form, formParams);
        form.addView(text("إضافة جهاز جديد", 16, true, Color.rgb(20, 35, 60)));
        TextView instruction = text("احفظ الاسم والموديل اختياريًا. الحفظ لا يبدأ تشخيصًا تلقائيًا.", 12, false, Color.rgb(99, 117, 141));
        instruction.setPadding(0, dp(5), 0, dp(9));
        form.addView(instruction);

        name = field("اسم الجهاز — مثال: ثلاجة المطبخ");
        form.addView(name, new LinearLayout.LayoutParams(-1, dp(50)));
        model = field("الماركة أو الموديل (اختياري)");
        LinearLayout.LayoutParams modelParams = new LinearLayout.LayoutParams(-1, dp(50));
        modelParams.setMargins(0, dp(8), 0, 0);
        form.addView(model, modelParams);

        MaterialButton add = new MaterialButton(this);
        add.setText("حفظ الجهاز");
        add.setTextSize(14);
        add.setTextColor(Color.WHITE);
        add.setCornerRadius(dp(13));
        add.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(23, 105, 224)));
        add.setInsetTop(0);
        add.setInsetBottom(0);
        LinearLayout.LayoutParams addParams = new LinearLayout.LayoutParams(-1, dp(48));
        addParams.setMargins(0, dp(10), 0, 0);
        form.addView(add, addParams);
        add.setOnClickListener(v -> saveDevice());

        LinearLayout listHeader = new LinearLayout(this);
        listHeader.setGravity(Gravity.CENTER_VERTICAL);
        listHeader.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        listHeader.addView(text("الأجهزة المحفوظة", 17, true, Color.rgb(20, 35, 60)), new LinearLayout.LayoutParams(0, -2, 1));
        count = text("0 جهاز", 12, true, Color.rgb(99, 117, 141));
        listHeader.addView(count);
        root.addView(listHeader);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        list.setPadding(0, dp(10), 0, dp(12));
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
        getWindow().setStatusBarColor(Color.rgb(242, 246, 252));
        getWindow().setNavigationBarColor(Color.rgb(242, 246, 252));
        refresh();
    }

    @Override protected void onResume() {
        super.onResume();
        if (list != null && store != null) refresh();
    }

    private EditText field(String hint) {
        EditText edit = new EditText(this);
        edit.setSingleLine(true);
        edit.setTextDirection(View.TEXT_DIRECTION_RTL);
        edit.setHint(hint);
        edit.setTextSize(14);
        edit.setPadding(dp(13), 0, dp(13), 0);
        edit.setBackgroundResource(R.drawable.bg_search);
        edit.setTextColor(Color.rgb(20, 35, 60));
        edit.setHintTextColor(Color.rgb(132, 145, 163));
        return edit;
    }

    private void saveDevice() {
        String deviceName = name.getText().toString().trim();
        if (deviceName.isEmpty()) {
            name.setError("اكتب اسم الجهاز أولًا");
            name.requestFocus();
            return;
        }
        store.saveDevice(deviceName, model.getText().toString().trim());
        name.setText("");
        model.setText("");
        Toast.makeText(this, "تم حفظ الجهاز", Toast.LENGTH_SHORT).show();
        refresh();
    }

    private void refresh() {
        list.removeAllViews();
        List<String> devices = store.devices();
        count.setText(devices.size() + (devices.size() == 1 ? " جهاز" : " أجهزة"));
        if (devices.isEmpty()) {
            LinearLayout empty = new LinearLayout(this);
            empty.setOrientation(LinearLayout.VERTICAL);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(20), dp(30), dp(20), dp(30));
            empty.setBackgroundResource(R.drawable.bg_card);
            TextView icon = text("▦", 32, true, Color.rgb(23, 105, 224));
            icon.setGravity(Gravity.CENTER);
            empty.addView(icon);
            TextView title = text("لم تحفظ أي جهاز حتى الآن", 15, true, Color.rgb(20, 35, 60));
            title.setGravity(Gravity.CENTER);
            title.setPadding(0, dp(8), 0, dp(4));
            empty.addView(title);
            TextView subtitle = text("أضف اسم جهازك أعلاه لتسهيل الرجوع إليه وبدء تشخيصه لاحقًا.", 12, false, Color.rgb(99, 117, 141));
            subtitle.setGravity(Gravity.CENTER);
            empty.addView(subtitle);
            list.addView(empty, new LinearLayout.LayoutParams(-1, -2));
            return;
        }

        for (String deviceLabel : devices) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            card.setPadding(dp(13), dp(12), dp(13), dp(12));
            card.setBackgroundResource(R.drawable.bg_card);
            card.setElevation(dp(1));
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
            cardParams.setMargins(0, 0, 0, dp(10));
            list.addView(card, cardParams);

            LinearLayout top = new LinearLayout(this);
            top.setGravity(Gravity.CENTER_VERTICAL);
            top.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            TextView icon = text("▦", 22, true, Color.rgb(23, 105, 224));
            icon.setGravity(Gravity.CENTER);
            icon.setBackgroundResource(R.drawable.bg_tint_blue);
            top.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));
            TextView label = text(deviceLabel, 15, true, Color.rgb(20, 35, 60));
            label.setPadding(dp(10), 0, dp(4), 0);
            top.addView(label, new LinearLayout.LayoutParams(0, -2, 1));
            TextView delete = text("حذف", 12, true, Color.rgb(180, 35, 24));
            delete.setPadding(dp(9), dp(8), dp(9), dp(8));
            top.addView(delete);
            delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("حذف الجهاز")
                .setMessage("هل تريد حذف «" + deviceLabel + "» من أجهزتك المحفوظة؟")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حذف", (dialog, which) -> {
                    store.deleteDevice(deviceLabel);
                    refresh();
                }).show());
            card.addView(top);

            TextView action = text("ابدأ تشخيص هذا الجهاز  ←", 12, true, Color.rgb(23, 105, 224));
            action.setPadding(0, dp(10), 0, 0);
            card.addView(action);
            View.OnClickListener diagnose = v -> {
                String cleanName = deviceLabel.contains(" — ") ? deviceLabel.substring(0, deviceLabel.indexOf(" — ")) : deviceLabel;
                Intent intent = new Intent(this, DiagnosisActivity.class);
                intent.putExtra("mode", cleanName);
                startActivity(intent);
            };
            card.setClickable(true);
            card.setFocusable(true);
            card.setOnClickListener(diagnose);
            action.setOnClickListener(diagnose);
        }
    }

    private TextView text(String value, int size, boolean bold, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTextDirection(View.TEXT_DIRECTION_RTL);
        if (bold) view.setTypeface(null, Typeface.BOLD);
        return view;
    }
}
