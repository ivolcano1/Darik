# DARIK Android Project — v28 Product Hardening & Diagnosis UX

## What's updated
- Compact right-to-left navigation drawer: 76% of screen width (maximum 312dp), 82% of screen height (maximum 620dp), rounded floating panel, outside area remains visible, and menu items scroll on short screens.
- Reduced menu row height and typography for better fit on smaller Android phones.
- Added system-bar insets to the home screen to avoid overlap with Android status/navigation areas on modern Android versions.
- Photo-assisted intake now clearly explains that photos are stored with the repair record and support visual documentation; offline diagnosis is based on the user's device/problem description and follow-up answers, not automatic image recognition.
- Attached photos no longer artificially increase the diagnostic match indicator.
- Version updated to 27.0.0. Existing local knowledge base (50 device/problem entries) and app data structures are retained.

## Build
The repository GitHub Actions workflow builds `:app:assembleDebug` using Java 17 and Gradle 8.9.

## Compatibility and size
- minSdk 24 (Android 7.0)
- targetSdk 34 (kept stable until edge-to-edge insets are implemented consistently across every activity)
- Compile SDK 35
- The project includes vector illustrations and small launcher PNG resources; no large bundled photo/video library is added.

## Important limitation
This version does not perform AI/computer-vision recognition of uploaded photos. The user attaches photos, then supplies a device name or symptom; the app matches that description against its offline knowledge base and asks follow-up questions. Do not present it as automatic image diagnosis.


## v28 changes
- Drawer width/height are clamped to the actual available screen bounds; removed the 232dp minimum that could overflow very narrow devices. Width is capped at 76% and 300dp; height at 80% and 600dp.
- Removed the uncalibrated percentage-style confidence display. The result now explicitly describes itself as guidance, shows answer/photo counts, and states that uploaded photos are not automatically interpreted.
- Updated all visible version labels to 28.0.0.
- Set targetSdk to 34 for this release candidate so Android 15 forced edge-to-edge behavior does not unexpectedly overlap secondary screens before their insets are fully implemented and tested. Minimum supported Android remains 7.0 (API 24).

## Validation status
- XML/JSON and archive integrity should be checked by CI during the Android build.
- This environment does not contain the Android Gradle build tool or a connected Android device, so no APK build, runtime, or device compatibility test is claimed here. GitHub Actions and physical-device testing remain required.
